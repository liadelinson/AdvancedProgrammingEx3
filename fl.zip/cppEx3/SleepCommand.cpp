//
// Created by sharon on 12/17/19.
//

#include "SleepCommand.h"
#include <thread>
int SleepCommand::execute(list<string> l) {
    cout << l.front() << endl;
    std::this_thread::sleep_for(std::chrono::seconds(20));

    return 2;
}