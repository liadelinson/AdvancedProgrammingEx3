//
// Created by sharon on 12/17/19.
//

#include "PrintCommand.h"
#include "Maps.h"
int PrintCommand::execute(list<string> l) {
    if (l.front().front() == '"' && l.front().back() == '\"') {
        l.front() = l.front().substr(1, l.front().size() - 2);
    } else {
        cout << Maps::symbolTable[l.front()]->_value << endl;
    }

    return 2;
}