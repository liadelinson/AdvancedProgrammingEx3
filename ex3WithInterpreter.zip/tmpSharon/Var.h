#ifndef UNTITLED1_VAR_H
#define UNTITLED1_VAR_H


#include "Expression.h"
using namespace std;

class Var : public Expression{

private:
    string name;

public:
    Var(string name);
    double calculate() override;
};


#endif //UNTITLED1_VAR_H
