//
// Created by liad on 30/12/2019.
//
#ifndef CPPEX3__INTERPRETEREX3_H_
#define CPPEX3__INTERPRETEREX3_H_

#include "ex1.h"

using namespace std;

class InterpreterEx3 {
 private:
  string setVariables(string str2);

 public:
  double calculateExpression(string str1);
};

#endif //CPPEX3__INTERPRETEREX3_H_
