#include <iostream>
#include <fstream>
#include <string>
#include "Lexer.h"
#include "Parser.h"
#include "Command.h"
#include "getVars.h"
#include "GlobalTables.h"
#include "ex1.h"
#include <vector>

using namespace std;

int main(int argc, char **argv) {
  Parser *p = new Parser();
  Lexer *l = new Lexer();
  vector<string> stringVec;
  ifstream infile(argv[1]);
  stringVec = l->fileLexer(infile);
  p->strPrs(stringVec);
  infile.close();
  delete p;
  delete l;
  return 0;
}
