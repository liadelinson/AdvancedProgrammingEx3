#include "Lexer.h"
#include "Parser.h"

int main(int argc, char **argv) {
  Parser *p = new Parser();
  Lexer *l = new Lexer();
  vector<string> stringVec;
  if (argc >= 1) {
    ifstream infile(argv[1]);
    stringVec = l->fileLexer(infile);
    infile.close();
    try {
      p->strPrs(stringVec);
    }
    catch (const char *e) {
      delete p;
      delete l;
      cout << e << endl;
      return -1;
    }
  }
  delete p;
  delete l;
  return 0;
}
