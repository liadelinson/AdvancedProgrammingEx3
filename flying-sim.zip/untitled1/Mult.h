#ifndef UNTITLED1_MULT_H
#define UNTITLED1_MULT_H


#include "BinaryExpression.h"

class Mult : public BinaryExpression {

public:
    Mult(Expression* leftExp, Expression* rightExp);

    double calculate() override;

    ~Mult();
};


#endif //UNTITLED1_MULT_H
