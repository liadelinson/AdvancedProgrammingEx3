#ifndef UNTITLED1_NEG_H
#define UNTITLED1_NEG_H
#include "UnaryExpression.h"

class Neg : public UnaryExpression {

public:

    Neg(Expression* e);

    Neg(double num);

    double calculate()override;
};


#endif //UNTITLED1_NEG_H
