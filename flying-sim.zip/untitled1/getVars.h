//
// Created by sharon on 12/28/19.
//

#ifndef UNTITLED1_GETVARS_H
#define UNTITLED1_GETVARS_H

#include <string>
#include <vector>

using namespace std;

class getVars {
public:
    static vector<string> getVariables(string s);
    static bool isOperator(char c);
};


#endif //UNTITLED1_GETVARS_H
