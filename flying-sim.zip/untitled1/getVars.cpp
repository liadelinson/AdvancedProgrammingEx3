//
// Created by sharon on 12/28/19.
//

#include "getVars.h"
#include <vector>

using namespace std;

vector<string> getVars::getVariables(string s) {
    string res = "";
    bool seenNonOperator = false;
    vector<string> temp;
    for (int i = 0; i < s.size(); i++) {
        if ((isOperator(s.at(i))) && !seenNonOperator) {
            continue;
        }
        if ((isOperator(s.at(i))) && seenNonOperator) {
            temp.push_back(res);
            res = "";
            continue;
        }
        seenNonOperator = true;
        res += s.at(i);
    }
    return temp;
}

bool getVars::isOperator(char c) {
    return c == '(' || c == '+' || c == '-' || c == '/' || c == '*' || c == ')' || c == '\n';
}