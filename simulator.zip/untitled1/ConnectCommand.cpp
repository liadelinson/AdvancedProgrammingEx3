#include "Command.h"
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include "ShuntingYard.h"
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include "GlobalTables.h"
#include <string.h>
#include "ConnectCommand.h"
#include <sys/socket.h>
#include <arpa/inet.h>>
using namespace std;

static int socketClient;
/**
 * function name: execute
 * operation: execute data
 * input: vec of strs and index
 * @return int val
 */
int ConnectCommand::execute(vector<string> cmdTemp, int index){
    ShuntingYard* sY = new ShuntingYard();
    int endLine = enterKey(cmdTemp, index);
   string ip = cmdTemp.at(index + 1);
   int porti =  sY->calculate(cmdTemp.at(index + 2));
   connectSocket(porti, ip);
   delete sY;
   return endLine;
}
/**
 * function name: connectSocket
 * operation: connect the socket
 * input: int and str
 * @return void
 */
void ConnectCommand::connectSocket(int port, string ip) {
   /* Create a socket point */
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        cerr << "Error creating socket" << endl;
        exit(1);
    }

    sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr("127.0.0.1");
    address.sin_port = htons(port);

    int is_connected = connect(sockfd, (struct sockaddr*) &address, sizeof(address));
    if (is_connected == -1) {
        cerr << "Error connecting to server" << endl;
        exit(1);
    }

    socketClient = sockfd;

    newOrder = "";
    pthread_t t2;
    pthread_create(&t2, NULL, &ConnectCommand::updateVal, this);
}
/**
 * function name: updateVal
 * operation: update the value
 * input: args*
 * @return void*
 */
void *ConnectCommand::updateVal(void *args) {
    pthread_mutex_t connect;
    connectLock = connect;
    char buffer[256];
    int n;
    runClient = true;
    pthread_mutex_lock(&connect);
    while (!endSignal) {

        /* Send message to the server */
        if (newOrder.length() > 0) {
            n = send(socketClient, newOrder.c_str(), strlen(newOrder.c_str()), 0);
            cout << "sent to simulator: " + newOrder << endl;

            if (n < 0) {
                perror("ERROR writing to socket");
                pthread_exit(NULL);
            }
            newOrder = "";

            n = read(socketClient, buffer, 256);
            cout << "recieved from simulator: " + string(buffer) << endl;
        }
    }
    pthread_mutex_unlock(&connect);
    pthread_exit(&args);
}
/**
 * function name: enterKey
 * operation: enter a key
 * input: vector of strs and index
 * @return int
 */
int ConnectCommand::enterKey(vector<string> vector, int index) {
    int i = 0;
    while(vector.at(index + i) != "\n") {
        i++;
    }
    return i;
}
/**
 * function name: vectorToString
 * operation:convert vec to str
 * input: vector of strs and index
 * @return string
 */
string ConnectCommand::vectorToString(vector<string> vector, int index, int end) {
    string ret = vector.at(index);
    int i = 1;
    while(i < end){
        ret += vector.at(index + i);
    }
    return ret;
}
//constructor
ConnectCommand::ConnectCommand() {

}

ConnectCommand::~ConnectCommand() = default;

