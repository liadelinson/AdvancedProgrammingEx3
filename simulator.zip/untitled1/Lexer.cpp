#include "Command.h"
#include "Lexer.h"
#include <fstream>


void Lexer::loopLexer(vector<string>* tempVec, string script) {
    int index = 0, beg = 0;
    for (char &c : script) {
        if (isspace(c) != 0 || c == '\n') {
            string tempStr = "";
            try {
                if (c == '\n') {
                    tempStr = script.substr(beg, index - beg);
                    tempVec->push_back(tempStr);
                    tempVec->push_back("\n");
                } else {
                    tempStr = script.substr(beg, index -
                                                 beg); //Create substring from index 'beg' to the location of next endline char
                    if (tempStr != "")
                        tempVec->push_back(tempStr); //Pushes in the vector the substring we created
                    beg += (index - beg) + 1;
                }
            }
            catch (std::out_of_range) {
                printf("End of array");
            }
            beg += (index - beg) + 1;
        }
        index++;
    }
}

vector<string> Lexer::fileLexer(ifstream& infile) {
    int index = 0, beg = 0;
    bool loop = false;
    string loopline = "";
    vector<string> tempVec; //Initialise vector where we'll insert our strings
    string line = "";
    while (getline(infile, line)) {

        if (line.substr(0, 14) == "openDataServer") {
            tempVec.push_back("openDataServer");
            tempVec.push_back(line.substr(15, 4));
            tempVec.push_back("\n");
            continue;
        }

        if (line.substr(0, 20) == "connectControlClient") {
            tempVec.push_back("connectControlClient");
            int i = 22;
            while (line.at(i) != '\"') {
                i++;
            }
            tempVec.push_back(line.substr(21, i- 21 + 1));
            i += 2;
            int j = i;
            while (line.at(j) != ')') {
                j++;
            }
            tempVec.push_back(line.substr(i, j-i));
            tempVec.push_back("\n");
            continue;
        }

        if (line.substr(0, 3) == "var") {
            tempVec.push_back("var");
            int i = 3;
            while(isspace(line.at(i))) {
                i++;
            }
            int j = i;
            while (!isspace(line.at(j))) {
                j++;
            }
            tempVec.push_back(line.substr(i, j-i));

            j++;
            int k = j;
            while (!isspace(line.at(k))) {
                k++;
            }

            tempVec.push_back(line.substr(j, k-j));

            if (line.substr(j, k-j) == "=") {
                k++;
                while (isspace(line.at(k))) {
                    k++;
                }
                tempVec.push_back(line.substr(k, line.length() - k + 1));
                tempVec.push_back("\n");
                continue;
            }

            k += 5;
            int r = k;
            while (line.at(r) != ')') {
                r++;
            }
            tempVec.push_back(line.substr(k, r-k));
            tempVec.push_back("\n");
            continue;
        }

        if (line.substr(0, 5) == "Print") {
            tempVec.push_back("Print");
            int i = 6;
            int j = i;
            while (line.at(j) != ')') {
                j++;
            }
            tempVec.push_back(line.substr(i, j-i));
            tempVec.push_back("\n");
            continue;
        }

        if (line.substr(0 , 5) == "Sleep") {
            tempVec.push_back("Sleep");
            int i = 6;
            int j = i;
            while (line.at(j) != ')') {
                j++;
            }
            tempVec.push_back(line.substr(i, j-i));
            tempVec.push_back("\n");
            continue;
        }

        if (line.substr(0, 5) == "while") {
            loopline += line;
            loopline += "\n";
            loop = true;
            continue;
        }

        if (loop) {
            if (line != "}\n" && line != "}") {
                loopline += line;
                continue;
            } else {
                loopline += "\n}\n";
                loopLexer(&tempVec, loopline);
                loop = false;
                loopline = "";
                continue;
            }
        }

        int i = 0;
        int j = i;
        while (!isspace(line.at(j)) && line.at(j) != '=') {
            j++;
        }
        tempVec.push_back(line.substr(i, j-i));

        if (line.at(j) == '=') {
            tempVec.push_back("=");
            j++;
            while (isspace(line.at(j))) {
                j++;
            }
            i = j;
            tempVec.push_back(line.substr(i, line.length() - i ));
            tempVec.push_back("\n");
            continue;
        }

        while (isspace(line.at(j))) {
            j++;
        }
        tempVec.push_back("=");
        j++;
        while (isspace(line.at(j))) {
            j++;
        }
        i = j;
        tempVec.push_back(line.substr(i, line.length() - i));
        tempVec.push_back("\n");
        continue;
    }

    return tempVec;
}

Lexer::Lexer() = default;

Lexer::~Lexer() = default;
