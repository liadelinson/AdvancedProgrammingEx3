#include "CommandExpression.h"

int CommandExpression::execute(vector<string> cmdTemp, int index) {
    return 0;
}

