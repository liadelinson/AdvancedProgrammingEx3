//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_SLEEPFACTORY_H
#define CPPEX3_SLEEPFACTORY_H

#include <string>
#include <list>
#include "SleepCommand.h"
#include "Factories.h"

using namespace std;

class SleepFactory : public Factory {
public:
    Command* getCommand(const list<string>& params) {
        return new SleepCommand(params);
    }
};

#endif //CPPEX3_SLEEPFACTORY_H
