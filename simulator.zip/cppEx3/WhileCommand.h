//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_WHILECOMMAND_H
#define CPPEX3_WHILECOMMAND_H

#include "Command.h"
#include <vector>
class WhileCommand : public Command {
private:
    list<string> params;
    vector<Command*> commands;
public:
    WhileCommand(const list<string>& params) {
        this->params = params;
    }
    int execute();
    void addCommand(Command* c);
};


#endif //CPPEX3_WHILECOMMAND_H
