//
// Created by sharon on 12/16/19.
//

#ifndef CPPEX3_IFCOMMAND_H
#define CPPEX3_IFCOMMAND_H

#include "ConditionParser.h"

class IfCommand : public ConditionParser {

};


#endif //CPPEX3_IFCOMMAND_H
