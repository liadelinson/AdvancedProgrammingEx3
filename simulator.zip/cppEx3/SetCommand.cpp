//
// Created by sharon on 12/18/19.
//

#include "SetCommand.h"
#include "simulatorCommunication.h"
#include "Maps.h"

int SetCommand::execute() {
    list<string> l = this->params;
    list<string>::const_iterator it = l.begin();
    string value = *it;
    advance(it, 2);
    string name = *it;

    cout << name + " " + value << endl;

    string withoutStart = (Maps::symbolTable[name]->_sim).substr(1, (Maps::symbolTable[name]->_sim).size() - 2);
    simulatorCommunication::sendToServer(withoutStart, stod(value));

    return 3;
}