//
// Created by sharon on 12/18/19.
//

#ifndef CPPEX3_SETCOMMAND_H
#define CPPEX3_SETCOMMAND_H

#include "Command.h"
#include <list>

class SetCommand : public Command {
private:
    list<string> params;
public:
    SetCommand(const list<string>& params) {
        this->params = params;
    }
    int execute();
    ~SetCommand() {};
};


#endif //CPPEX3_SETCOMMAND_H