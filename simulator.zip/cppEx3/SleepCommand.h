//
// Created by sharon on 12/17/19.
//

#ifndef CPPEX3_SLEEPCOMMAND_H
#define CPPEX3_SLEEPCOMMAND_H

#include "Command.h"

class SleepCommand : public Command {
private:
    list<string> params;
public:
    SleepCommand(const list<string>& params) {
        this->params = params;
    }
    int execute();
};


#endif //CPPEX3_SLEEPCOMMAND_H
