//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_WHILEFACTORY_H
#define CPPEX3_WHILEFACTORY_H

#include <string>
#include <list>
#include "WhileCommand.h"
#include "Factories.h"

using namespace std;

class WhileFactory : public Factory {
public:
    Command* getCommand(const list<string>& params) {
        return new WhileCommand(params);
    }
};

#endif //CPPEX3_WHILEFACTORY_H
