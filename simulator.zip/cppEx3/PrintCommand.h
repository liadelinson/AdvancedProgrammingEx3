//
// Created by sharon on 12/17/19.
//

#ifndef CPPEX3_PRINTCOMMAND_H
#define CPPEX3_PRINTCOMMAND_H

#include "Command.h"

class PrintCommand : public Command {
private:
    list<string> params;
public:
    PrintCommand(const list<string>& params) {
        this->params = params;
    }
    int execute();
    ~PrintCommand() {};
};


#endif //CPPEX3_PRINTCOMMAND_H
