//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_CONNECTFACTORY_H
#define CPPEX3_CONNECTFACTORY_H

#include <string>
#include <list>
#include "ConnectCommand.h"
#include "Factories.h"

using namespace std;

class ConnectFactory : public Factory {
public:
    Command* getCommand(const list<string>& params) {
        return new ConnectCommand(params);
    }
};

#endif //CPPEX3_CONNECTFACTORY_H
