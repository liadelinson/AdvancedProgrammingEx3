//
// Created by sharon on 12/15/19.
//

#ifndef CPPEX3_VARCOMMAND_H
#define CPPEX3_VARCOMMAND_H

#include "Command.h"

class VarCommand : public Command {
private:
    list<string> params;
public:
    VarCommand(const list<string>& params) {
        this->params = params;
    }
    ~VarCommand() {};
    int execute();
};


#endif //CPPEX3_VARCOMMAND_H
