//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_VARFACTORY_H
#define CPPEX3_VARFACTORY_H

#include <string>
#include <list>
#include "VarCommand.h"
#include "Factories.h"

using namespace std;

class VarFactory : public Factory {
public:
    Command* getCommand(const list<string>& params) {
        return new VarCommand(params);
    }
};

#endif //CPPEX3_VARFACTORY_H
