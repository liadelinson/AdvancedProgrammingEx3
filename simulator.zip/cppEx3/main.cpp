#include "Command.h"
#include "Lexer.h"
#include "Factories.h"
#include "ConnectFactory.h"
#include "OpenServerFactory.h"
#include "VarFactory.h"
#include "PrintFactory.h"
#include "SleepFactory.h"
#include "WhileFactory.h"
#include "SetFactory.h"
#include <unordered_map>
#include <iostream>

using namespace std;

void parser(unordered_map<string, Factory*> commands, unordered_map<string, int> jumps, list<string> tokenList) {
    list<string>::iterator it = tokenList.begin();
    list<string> params;

    //cout << "now parsing: " + *it << endl;

    while (it != tokenList.end()) {
        //cout << "now parsing: " + *it << endl;

        list<string>::iterator currentLocation = it;

        if (*it == "while" || *it == "If") {
            if (*it == "while") {
                vector<Command*> commandsToAdd;
                list<string> param;

                it++;
                param.insert(param.end(), *it);
                advance(it, 2);

                while (*it != "}") {
                    list<string>::iterator current = it;

                    ++current;

                    for (int i = 0; i < jumps[*it]; i++) {
                        params.insert(params.begin(), *current);
                        ++current;
                    }

                    Command* a = (commands[*it])->getCommand(params);
                    commandsToAdd.insert(commandsToAdd.end(), a);
                    advance(it, jumps[*it] + 1);
                    params.clear();
                }

                WhileCommand* f = new WhileCommand(param);
                for (auto it = commandsToAdd.begin(); it != commandsToAdd.end(); it++) {
                    f->addCommand(*it);
                }
                f->execute();
                delete(f);
                it++;
                continue;
            }
        }

        ++currentLocation;

        if (*it != "Print" && *currentLocation == "=") {
            params.insert(params.begin(), *it);
            params.insert(params.begin(), "=");
            ++currentLocation;
            params.insert(params.begin(), *currentLocation);

            Factory* c = new SetFactory();
            Command* a = c->getCommand(params);
            advance(it, a->execute());
            delete(a);
            params.clear();
            continue;
        }

        for (int i = 0; i < jumps[*it]; i++) {
            params.insert(params.begin(), *currentLocation);
            ++currentLocation;
        }

        /*for (auto it = params.begin(); it != params.end(); it++) {
            cout << *it << endl;
        }*/

        Command* a = (commands[*it])->getCommand(params);
        advance(it, a->execute());
        delete(a);
        params.clear();
    }
}

int main(int argc, char* argv[]) {

    unordered_map<string, Factory*> commandsMap;
    unordered_map<string, int> jumpMap;

    commandsMap.insert(pair<string, Factory*>("openDataServer", new OpenServerFactory()));
    commandsMap.insert(pair<string, Factory*>("connectControlClient", new ConnectFactory()));
    commandsMap.insert(pair<string, Factory*>("var", new VarFactory()));
    commandsMap.insert(pair<string, Factory*>("Print", new PrintFactory()));
    commandsMap.insert(pair<string, Factory*>("Sleep", new SleepFactory()));
    commandsMap.insert(pair<string, Factory*>("while", new WhileFactory()));

    jumpMap.insert(pair<string, int>("openDataServer", 1));
    jumpMap.insert(pair<string, int>("connectControlClient", 2));
    jumpMap.insert(pair<string, int>("var", 4));
    jumpMap.insert(pair<string, int>("Print", 1));
    jumpMap.insert(pair<string, int>("Sleep", 1));

    fstream f;
    f.open("fly.txt", ios::in);
    Lexer* a = new Lexer;
    a->readFile(f);
    //a->printAll();

    parser(commandsMap, jumpMap, a->finalList);

    return 0;
}
