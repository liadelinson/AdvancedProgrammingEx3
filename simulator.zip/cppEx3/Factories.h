//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_FACTORIES_H
#define CPPEX3_FACTORIES_H

class Factory {
public:
    virtual Command* getCommand(const list<string>& params) {};
    virtual ~Factory() {};
};

#endif //CPPEX3_FACTORIES_H
