//
// Created by sharon on 12/16/19.
//

#include "ConditionParser.h"
#include "IfCommand.h"

ConditionParser::ConditionParser() {

}

int ConditionParser::execute(list<string> l) {

}