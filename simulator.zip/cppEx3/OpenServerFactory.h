//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_OPENSERVERFACTORY_H
#define CPPEX3_OPENSERVERFACTORY_H

#include <string>
#include <list>
#include "OpenServerCommand.h"

using namespace std;

class OpenServerFactory : public Factory {
public:
    Command* getCommand(const list<string>& params) {
        return new OpenServerCommand(params);
    }
    ~OpenServerFactory() {};
};

#endif //CPPEX3_OPENSERVERFACTORY_H
