//
// Created by sharon on 12/20/19.
//

#include "WhileCommand.h"
#include "Maps.h"

int WhileCommand::execute() {
    list<string>::const_iterator it = this->params.begin();

    string cond = *it;
    string cond2 = *it;
    string cond3 = *it;
    std::size_t found = cond.find_first_of(">,<,=");
    cond = cond.substr(0, found);
    std::size_t  f = cond2.find_last_of(">,<,=");
    cond2 = cond2.substr(found, f-2);
    cond3 = cond3.substr(f + 1, cond3.size() - 1);

    //cout << cond + " " + cond2 + " " + cond3 << endl;

    if (cond2 == "<=") {
        while (Maps::symbolTable[cond]->_value <= stod(cond3)) {
            for (auto it = commands.begin(); it != commands.end(); it++) {
                //(*it)->execute();
            }
        }
    }

    return 0;

}

void WhileCommand::addCommand(class Command * c) {
    commands.insert(commands.begin(), c);
}