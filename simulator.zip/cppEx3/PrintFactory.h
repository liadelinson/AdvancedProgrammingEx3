//
// Created by sharon on 12/20/19.
//

#ifndef CPPEX3_PRINTFACTORY_H
#define CPPEX3_PRINTFACTORY_H

#include <string>
#include <list>
#include "PrintCommand.h"
#include "Factories.h"

using namespace std;

class PrintFactory : public Factory {
public:
    Command* getCommand(const list<string>& params) {
        return new PrintCommand(params);
    }
    ~PrintFactory() {};
};

#endif //CPPEX3_PRINTFACTORY_H
